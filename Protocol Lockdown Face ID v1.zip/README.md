# Face ID Login App

## High-level Strategy and Goal
A facial recognition login application that uses face-api.js to detect, register, and authenticate users via their webcam. No server-side authentication needed — face descriptors are stored in localStorage for a fully client-side biometric experience. When embedded as an iframe, the app communicates verification results to the host website via postMessage.

## Changes Implemented
1. **Face ID App Component** (`src/components/FaceIdApp.tsx`): Full facial recognition flow with states for loading, camera permission, registration, login scanning, not-recognized, and logged-in home screen.
2. **Camera Prompt** (`src/components/CameraPrompt.tsx`): Explicit camera permission screen shown before webcam starts. Detects iframe restrictions and offers "Open in New Tab" fallback.
3. **Layout updates**: Dark theme enforced, face-api.js loaded from CDN via script tag.
4. **Global CSS**: Added scan line animation for the login scanning overlay.
5. **Home page**: Dynamically imports FaceIdApp with SSR disabled (requires browser APIs).
6. **Host Communication** (`src/lib/face-id-messaging.ts`): postMessage-based communication layer for embedded iframe usage. Sends verification success/failure and status updates to the host window. Listens for commands (lock, reset, request-status) from the host.
7. **Embedded Mode Indicator**: "Host notified" badge shown on the logged-in screen when running inside an iframe.

## Architecture and Technical Decisions
- **face-api.js from CDN**: Loaded as a global script to avoid SSR issues. Models loaded from vladmandic's fork CDN (more reliable hosting).
- **Client-side only**: All face detection, registration, and matching happens in the browser. No server involvement.
- **localStorage**: Face descriptors stored as JSON arrays. Simple single-user model.
- **Euclidean distance threshold**: 0.6 for face matching (standard recommended threshold for face-api.js).
- **Dynamic import with `ssr: false`**: Prevents hydration issues since the component relies on browser APIs (navigator.mediaDevices, localStorage, etc.).
- **postMessage API**: When embedded in an iframe, the app posts `FACE_ID_VERIFICATION` messages (success with userName, confidence, timestamp, sessionToken; or failure) and `FACE_ID_STATUS` updates to the parent window. The host can send `FACE_ID_COMMAND` messages (lock, reset, request-status) to control the app.
- **Session token**: Each successful verification generates a random 48-character hex token the host can use to track the authenticated session.

## Host Integration Guide

### Embedding
```html
<iframe src="https://your-face-id-app.com" allow="camera" width="500" height="600"></iframe>
```

### Listening for Verification
```javascript
window.addEventListener("message", (event) => {
  if (event.data?.type === "FACE_ID_VERIFICATION") {
    if (event.data.success) {
      const { userName, confidence, timestamp, sessionToken } = event.data.payload;
      console.log(`Verified: ${userName} (${confidence}% confidence)`);
      // Grant access, store session, etc.
    } else {
      console.log("Face ID verification failed");
    }
  }
  if (event.data?.type === "FACE_ID_STATUS") {
    console.log(`Status: ${event.data.status}`, event.data.detail);
  }
});
```

### Sending Commands
```javascript
const iframe = document.querySelector("iframe");
iframe.contentWindow.postMessage({ type: "FACE_ID_COMMAND", command: "lock" }, "*");
iframe.contentWindow.postMessage({ type: "FACE_ID_COMMAND", command: "reset" }, "*");
iframe.contentWindow.postMessage({ type: "FACE_ID_COMMAND", command: "request-status" }, "*");
```