/* ------------------------------------------------------------------ */
/*  Types                                                              */
/* ------------------------------------------------------------------ */

export type AppState =
  | "loading"
  | "camera-prompt"
  | "register"
  | "login-scan"
  | "logged-in"
  | "not-recognized";

export interface StoredFace {
  name: string;
  descriptor: number[];
}

/* ------------------------------------------------------------------ */
/*  Helpers                                                            */
/* ------------------------------------------------------------------ */

export const MODEL_URL =
  "https://cdn.jsdelivr.net/npm/@vladmandic/face-api@1.7.13/model/";

export function euclideanDistance(a: number[], b: number[]): number {
  let sum = 0;
  for (let i = 0; i < a.length; i++) {
    const diff = (a[i] ?? 0) - (b[i] ?? 0);
    sum += diff * diff;
  }
  return Math.sqrt(sum);
}

export function getGreeting(): string {
  const h = new Date().getHours();
  if (h < 12) return "Good morning";
  if (h < 17) return "Good afternoon";
  return "Good evening";
}

export function formatTime(d: Date): string {
  return d.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
}

export function formatDate(d: Date): string {
  return d.toLocaleDateString([], {
    weekday: "long",
    year: "numeric",
    month: "long",
    day: "numeric",
  });
}

export function getStoredFace(): StoredFace | null {
  try {
    const stored = localStorage.getItem("faceIdData");
    if (!stored) return null;
    return JSON.parse(stored) as StoredFace;
  } catch {
    return null;
  }
}

export function saveStoredFace(data: StoredFace): void {
  localStorage.setItem("faceIdData", JSON.stringify(data));
}

export function clearStoredFace(): void {
  localStorage.removeItem("faceIdData");
}
