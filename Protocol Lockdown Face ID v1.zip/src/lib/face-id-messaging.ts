/* ------------------------------------------------------------------ */
/*  Face ID  ↔  Host Window  postMessage Communication Layer          */
/* ------------------------------------------------------------------ */

/**
 * Message sent FROM the Face ID app TO the host/parent window
 * when verification succeeds or fails.
 */
export interface FaceIdVerificationMessage {
  type: "FACE_ID_VERIFICATION";
  success: boolean;
  payload: {
    userName: string;
    confidence: number; // 0-100
    timestamp: string; // ISO string
    sessionToken: string; // random token for the host to track the session
  } | null;
}

/**
 * Status update messages sent to the host during the Face ID process.
 */
export interface FaceIdStatusMessage {
  type: "FACE_ID_STATUS";
  status:
    | "loading"
    | "camera-prompt"
    | "scanning"
    | "registering"
    | "matched"
    | "not-recognized"
    | "locked"
    | "error";
  detail?: string;
}

/**
 * Message sent FROM the host TO the Face ID app to request actions.
 */
export interface FaceIdHostCommand {
  type: "FACE_ID_COMMAND";
  command: "request-status" | "lock" | "reset";
}

export type FaceIdOutgoingMessage = FaceIdVerificationMessage | FaceIdStatusMessage;
export type FaceIdIncomingMessage = FaceIdHostCommand;

/* ------------------------------------------------------------------ */
/*  Helpers                                                            */
/* ------------------------------------------------------------------ */

function isEmbedded(): boolean {
  try {
    return window.self !== window.top;
  } catch {
    return true; // cross-origin iframe
  }
}

function generateSessionToken(): string {
  const arr = new Uint8Array(24);
  crypto.getRandomValues(arr);
  return Array.from(arr, (b) => b.toString(16).padStart(2, "0")).join("");
}

/* ------------------------------------------------------------------ */
/*  Send messages to parent / host                                     */
/* ------------------------------------------------------------------ */

/**
 * Post a message to the parent window. Uses `"*"` as target origin so it
 * works regardless of host domain. The host should validate the message
 * `type` field on their end.
 */
function postToHost(message: FaceIdOutgoingMessage) {
  if (!isEmbedded()) return;
  try {
    window.parent.postMessage(message, "*");
  } catch {
    // silently ignore if parent is inaccessible
  }
}

/** Notify the host that Face ID verification succeeded. */
export function notifyVerificationSuccess(
  userName: string,
  confidence: number,
): FaceIdVerificationMessage {
  const message: FaceIdVerificationMessage = {
    type: "FACE_ID_VERIFICATION",
    success: true,
    payload: {
      userName,
      confidence,
      timestamp: new Date().toISOString(),
      sessionToken: generateSessionToken(),
    },
  };
  postToHost(message);
  return message;
}

/** Notify the host that Face ID verification failed. */
export function notifyVerificationFailure(): FaceIdVerificationMessage {
  const message: FaceIdVerificationMessage = {
    type: "FACE_ID_VERIFICATION",
    success: false,
    payload: null,
  };
  postToHost(message);
  return message;
}

/** Send a status update to the host. */
export function notifyStatus(
  status: FaceIdStatusMessage["status"],
  detail?: string,
) {
  const message: FaceIdStatusMessage = {
    type: "FACE_ID_STATUS",
    status,
    detail,
  };
  postToHost(message);
}

/* ------------------------------------------------------------------ */
/*  Listen for commands from the host                                  */
/* ------------------------------------------------------------------ */

export type HostCommandHandler = (command: FaceIdHostCommand["command"]) => void;

/**
 * Start listening for postMessage commands from the parent window.
 * Returns a cleanup function to remove the listener.
 */
export function listenForHostCommands(handler: HostCommandHandler): () => void {
  function onMessage(event: MessageEvent) {
    const data = event.data;
    if (
      data &&
      typeof data === "object" &&
      data.type === "FACE_ID_COMMAND" &&
      typeof data.command === "string"
    ) {
      handler(data.command as FaceIdHostCommand["command"]);
    }
  }

  window.addEventListener("message", onMessage);
  return () => window.removeEventListener("message", onMessage);
}

/** Check whether we're running embedded in another site. */
export { isEmbedded };
