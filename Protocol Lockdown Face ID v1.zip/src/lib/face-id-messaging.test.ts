import {
  notifyVerificationSuccess,
  notifyVerificationFailure,
  notifyStatus,
  listenForHostCommands,
  isEmbedded,
} from "./face-id-messaging";

describe("face-id-messaging", () => {
  describe("isEmbedded", () => {
    it("returns false when window.self === window.top", () => {
      // In the test env, self === top (no iframe)
      expect(isEmbedded()).toBe(false);
    });
  });

  describe("notifyVerificationSuccess", () => {
    it("returns a FACE_ID_VERIFICATION message with success true", () => {
      const msg = notifyVerificationSuccess("Alice", 95);
      expect(msg.type).toBe("FACE_ID_VERIFICATION");
      expect(msg.success).toBe(true);
      expect(msg.payload).not.toBeNull();
      expect(msg.payload!.userName).toBe("Alice");
      expect(msg.payload!.confidence).toBe(95);
      expect(msg.payload!.sessionToken).toBeTruthy();
      expect(msg.payload!.timestamp).toBeTruthy();
    });

    it("generates a unique session token each time", () => {
      const msg1 = notifyVerificationSuccess("Bob", 80);
      const msg2 = notifyVerificationSuccess("Bob", 80);
      expect(msg1.payload!.sessionToken).not.toBe(msg2.payload!.sessionToken);
    });

    it("includes a valid ISO timestamp", () => {
      const before = new Date().toISOString();
      const msg = notifyVerificationSuccess("Test", 50);
      const after = new Date().toISOString();
      expect(msg.payload!.timestamp >= before).toBe(true);
      expect(msg.payload!.timestamp <= after).toBe(true);
    });
  });

  describe("notifyVerificationFailure", () => {
    it("returns a FACE_ID_VERIFICATION message with success false", () => {
      const msg = notifyVerificationFailure();
      expect(msg.type).toBe("FACE_ID_VERIFICATION");
      expect(msg.success).toBe(false);
      expect(msg.payload).toBeNull();
    });
  });

  describe("notifyStatus", () => {
    it("does not throw when called (non-embedded)", () => {
      expect(() => notifyStatus("scanning", "Looking for face")).not.toThrow();
      expect(() => notifyStatus("matched")).not.toThrow();
      expect(() => notifyStatus("loading")).not.toThrow();
    });
  });

  describe("listenForHostCommands", () => {
    it("calls handler when a valid FACE_ID_COMMAND message is received", () => {
      const handler = jest.fn();
      const cleanup = listenForHostCommands(handler);

      window.dispatchEvent(
        new MessageEvent("message", {
          data: { type: "FACE_ID_COMMAND", command: "lock" },
        })
      );

      expect(handler).toHaveBeenCalledWith("lock");
      cleanup();
    });

    it("calls handler for reset command", () => {
      const handler = jest.fn();
      const cleanup = listenForHostCommands(handler);

      window.dispatchEvent(
        new MessageEvent("message", {
          data: { type: "FACE_ID_COMMAND", command: "reset" },
        })
      );

      expect(handler).toHaveBeenCalledWith("reset");
      cleanup();
    });

    it("calls handler for request-status command", () => {
      const handler = jest.fn();
      const cleanup = listenForHostCommands(handler);

      window.dispatchEvent(
        new MessageEvent("message", {
          data: { type: "FACE_ID_COMMAND", command: "request-status" },
        })
      );

      expect(handler).toHaveBeenCalledWith("request-status");
      cleanup();
    });

    it("ignores messages without FACE_ID_COMMAND type", () => {
      const handler = jest.fn();
      const cleanup = listenForHostCommands(handler);

      window.dispatchEvent(
        new MessageEvent("message", {
          data: { type: "SOME_OTHER_TYPE", command: "lock" },
        })
      );

      expect(handler).not.toHaveBeenCalled();
      cleanup();
    });

    it("ignores non-object messages", () => {
      const handler = jest.fn();
      const cleanup = listenForHostCommands(handler);

      window.dispatchEvent(
        new MessageEvent("message", { data: "just a string" })
      );
      window.dispatchEvent(new MessageEvent("message", { data: null }));
      window.dispatchEvent(new MessageEvent("message", { data: 42 }));

      expect(handler).not.toHaveBeenCalled();
      cleanup();
    });

    it("ignores messages where command is not a string", () => {
      const handler = jest.fn();
      const cleanup = listenForHostCommands(handler);

      window.dispatchEvent(
        new MessageEvent("message", {
          data: { type: "FACE_ID_COMMAND", command: 123 },
        })
      );

      expect(handler).not.toHaveBeenCalled();
      cleanup();
    });

    it("stops listening after cleanup", () => {
      const handler = jest.fn();
      const cleanup = listenForHostCommands(handler);
      cleanup();

      window.dispatchEvent(
        new MessageEvent("message", {
          data: { type: "FACE_ID_COMMAND", command: "lock" },
        })
      );

      expect(handler).not.toHaveBeenCalled();
    });
  });
});
