// Unit tests for Face ID utility functions

function euclideanDistance(a: number[], b: number[]): number {
  let sum = 0;
  for (let i = 0; i < a.length; i++) {
    const diff = (a[i] ?? 0) - (b[i] ?? 0);
    sum += diff * diff;
  }
  return Math.sqrt(sum);
}

function getGreeting(hour: number): string {
  if (hour < 12) return "Good morning";
  if (hour < 17) return "Good afternoon";
  return "Good evening";
}

describe("euclideanDistance", () => {
  test("returns 0 for identical vectors", () => {
    const v = [0.1, 0.2, 0.3, 0.4];
    expect(euclideanDistance(v, v)).toBe(0);
  });

  test("calculates correct distance for simple vectors", () => {
    expect(euclideanDistance([0, 0, 0], [3, 4, 0])).toBe(5);
  });

  test("returns correct distance for unit difference", () => {
    expect(euclideanDistance([1, 0], [0, 0])).toBe(1);
  });

  test("handles empty arrays", () => {
    expect(euclideanDistance([], [])).toBe(0);
  });

  test("similar descriptors give distance below 0.6 threshold", () => {
    const d1 = Array.from({ length: 128 }, (_, i) => Math.sin(i) * 0.1);
    const d2 = d1.map((v) => v + (Math.random() - 0.5) * 0.01);
    expect(euclideanDistance(d1, d2)).toBeLessThan(0.6);
  });

  test("very different descriptors give distance above 0.6 threshold", () => {
    const d1 = Array.from({ length: 128 }, () => 0.5);
    const d2 = Array.from({ length: 128 }, () => -0.5);
    expect(euclideanDistance(d1, d2)).toBeGreaterThan(0.6);
  });
});

describe("getGreeting", () => {
  test("returns Good morning for hours 0-11", () => {
    expect(getGreeting(0)).toBe("Good morning");
    expect(getGreeting(6)).toBe("Good morning");
    expect(getGreeting(11)).toBe("Good morning");
  });

  test("returns Good afternoon for hours 12-16", () => {
    expect(getGreeting(12)).toBe("Good afternoon");
    expect(getGreeting(16)).toBe("Good afternoon");
  });

  test("returns Good evening for hours 17-23", () => {
    expect(getGreeting(17)).toBe("Good evening");
    expect(getGreeting(23)).toBe("Good evening");
  });
});

describe("face data serialization", () => {
  test("serializes and deserializes face data correctly", () => {
    const data = { name: "Alice", descriptor: [0.1, 0.2, 0.3] };
    const json = JSON.stringify(data);
    const parsed = JSON.parse(json);
    expect(parsed.name).toBe("Alice");
    expect(parsed.descriptor).toEqual([0.1, 0.2, 0.3]);
  });

  test("preserves 128-dimension descriptor through serialization", () => {
    const descriptor = Array.from({ length: 128 }, (_, i) => Math.sin(i) * 0.5);
    const data = { name: "Test", descriptor };
    const parsed = JSON.parse(JSON.stringify(data));
    expect(parsed.descriptor.length).toBe(128);
    expect(parsed.descriptor[0]).toBeCloseTo(descriptor[0]!, 10);
  });
});
