"use client";

import React from "react";

interface CameraPromptProps {
  mode: "register" | "login-scan";
  userName: string;
  cameraError: string | null;
  onGrantCamera: () => void;
}

export default function CameraPrompt({
  mode,
  userName,
  cameraError,
  onGrantCamera,
}: CameraPromptProps) {
  return (
    <div className="flex min-h-screen items-center justify-center bg-[#0a0a0f] p-4">
      <div className="w-full max-w-[500px] animate-in fade-in slide-in-from-bottom-4 duration-500">
        <div className="rounded-3xl border border-[#1a1a2e] bg-[#0f0f1a] p-8 text-center shadow-[0_0_60px_rgba(59,130,246,0.05)]">
          {/* Camera icon */}
          <div className="mx-auto mb-6 flex h-24 w-24 items-center justify-center rounded-full bg-[#3b82f6]/10">
            <svg
              width="48"
              height="48"
              viewBox="0 0 24 24"
              fill="none"
              stroke="#3b82f6"
              strokeWidth="1.5"
              strokeLinecap="round"
              strokeLinejoin="round"
            >
              <path d="M23 19a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h4l2-3h6l2 3h4a2 2 0 0 1 2 2z" />
              <circle cx="12" cy="13" r="4" />
            </svg>
          </div>

          <h1 className="text-2xl font-bold text-white">
            Camera Access Required
          </h1>
          <p className="mt-3 text-sm leading-relaxed text-gray-400">
            {mode === "register"
              ? "To set up Face ID, we need access to your camera. Your face data stays on this device and is never uploaded."
              : `To sign you in, we need access to your camera. Welcome back${userName ? `, ${userName}` : ""}!`}
          </p>

          {/* Error message */}
          {cameraError && (
            <div className="mt-5 rounded-xl bg-red-500/10 px-4 py-3 text-sm text-red-400">
              <p>{cameraError}</p>
              {cameraError.includes("embedded") && (
                <button
                  onClick={() => window.open(window.location.href, "_blank")}
                  className="mt-3 inline-flex items-center gap-1.5 rounded-lg bg-[#3b82f6]/20 px-4 py-2 text-sm font-medium text-[#60a5fa] transition hover:bg-[#3b82f6]/30"
                >
                  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6" />
                    <polyline points="15 3 21 3 21 9" />
                    <line x1="10" y1="14" x2="21" y2="3" />
                  </svg>
                  Open in New Tab
                </button>
              )}
            </div>
          )}

          {/* Grant access button */}
          <button
            onClick={onGrantCamera}
            className="mt-8 w-full rounded-xl bg-[#3b82f6] px-6 py-3.5 font-semibold text-white transition hover:bg-[#2563eb] active:scale-[0.98]"
          >
            {cameraError ? "Try Again" : "Allow Camera Access"}
          </button>

          {/* Privacy note */}
          <div className="mt-6 flex items-start gap-2 text-left">
            <svg
              className="mt-0.5 shrink-0"
              width="14"
              height="14"
              viewBox="0 0 24 24"
              fill="none"
              stroke="#6b7280"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
            >
              <rect x="3" y="11" width="18" height="11" rx="2" ry="2" />
              <path d="M7 11V7a5 5 0 0 1 10 0v4" />
            </svg>
            <p className="text-xs leading-relaxed text-gray-500">
              Your face data is stored locally on this device using
              localStorage. It is never sent to any server.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}