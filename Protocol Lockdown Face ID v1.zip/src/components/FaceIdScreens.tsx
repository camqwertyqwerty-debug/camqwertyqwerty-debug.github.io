"use client";

import React from "react";
import { getGreeting, formatDate, formatTime } from "@/lib/face-id-utils";

/* ------------------------------------------------------------------ */
/*  Loading Screen                                                     */
/* ------------------------------------------------------------------ */

export function LoadingScreen({ progress }: { progress: number }) {
  return (
    <div className="flex min-h-screen items-center justify-center bg-[#0a0a0f]">
      <div className="flex flex-col items-center gap-6">
        <div className="relative h-20 w-20">
          <div className="absolute inset-0 rounded-full border-4 border-[#1a1a2e]" />
          <div className="absolute inset-0 animate-spin rounded-full border-4 border-transparent border-t-[#3b82f6]" />
          <div
            className="absolute inset-2 animate-spin rounded-full border-4 border-transparent border-b-[#60a5fa]"
            style={{ animationDirection: "reverse", animationDuration: "1.5s" }}
          />
        </div>
        <div className="text-center">
          <p className="text-lg font-medium text-white">Loading Face Recognition...</p>
          <div className="mt-3 h-1.5 w-64 overflow-hidden rounded-full bg-[#1a1a2e]">
            <div
              className="h-full rounded-full bg-gradient-to-r from-[#3b82f6] to-[#60a5fa] transition-all duration-500"
              style={{ width: `${progress}%` }}
            />
          </div>
          <p className="mt-2 text-sm text-gray-500">
            {progress < 45
              ? "Loading detection model..."
              : progress < 75
                ? "Loading landmark model..."
                : progress < 100
                  ? "Loading recognition model..."
                  : "Almost ready..."}
          </p>
        </div>
      </div>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/*  Not Recognized Screen                                              */
/* ------------------------------------------------------------------ */

export function NotRecognizedScreen({
  onRetry,
  onReset,
}: {
  onRetry: () => void;
  onReset: () => void;
}) {
  return (
    <div className="flex min-h-screen items-center justify-center bg-[#0a0a0f] p-4">
      <div className="w-full max-w-[500px] text-center">
        <div className="mx-auto mb-6 flex h-20 w-20 items-center justify-center rounded-full bg-red-500/10">
          <svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="#ef4444" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <circle cx="12" cy="12" r="10" />
            <line x1="15" y1="9" x2="9" y2="15" />
            <line x1="9" y1="9" x2="15" y2="15" />
          </svg>
        </div>
        <h1 className="text-2xl font-bold text-white">Face not recognized</h1>
        <p className="mt-2 text-gray-400">We couldn&apos;t match your face. Please try again.</p>
        <div className="mt-8 flex flex-col items-center gap-3">
          <button onClick={onRetry} className="w-64 rounded-xl bg-[#3b82f6] px-6 py-3 font-semibold text-white transition hover:bg-[#2563eb]">
            Try Again
          </button>
          <button onClick={onReset} className="rounded-lg px-4 py-2 text-sm text-gray-500 transition hover:text-gray-300">
            Reset Face ID
          </button>
        </div>
      </div>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/*  Logged In Screen                                                   */
/* ------------------------------------------------------------------ */

export function LoggedInScreen({
  userName,
  loginTime,
  confidence,
  onLock,
  onReset,
  embedded = false,
}: {
  userName: string;
  loginTime: Date | null;
  confidence: number;
  onLock: () => void;
  onReset: () => void;
  embedded?: boolean;
}) {
  return (
    <div className="flex min-h-screen items-center justify-center bg-[#0a0a0f] p-4">
      <div className="w-full max-w-[500px] animate-in fade-in slide-in-from-bottom-4 duration-500">
        <div className="rounded-3xl border border-[#1a1a2e] bg-[#0f0f1a] p-8 shadow-[0_0_60px_rgba(59,130,246,0.05)]">
          <div className="text-center">
            <div className="mx-auto mb-4 flex h-20 w-20 items-center justify-center rounded-full bg-gradient-to-br from-[#3b82f6] to-[#8b5cf6]">
              <span className="text-3xl font-bold text-white">{userName.charAt(0).toUpperCase()}</span>
            </div>
            <p className="text-lg text-[#60a5fa]">{getGreeting()}</p>
            <h1 className="mt-1 text-3xl font-bold text-white">Welcome, {userName}</h1>
          </div>

          {loginTime && (
            <div className="mt-8 rounded-2xl bg-[#0a0a0f] p-5">
              <div className="flex items-center gap-3">
                <div className="flex h-10 w-10 items-center justify-center rounded-full bg-green-500/10">
                  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#22c55e" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <polyline points="20 6 9 17 4 12" />
                  </svg>
                </div>
                <div>
                  <p className="text-sm font-medium text-white">Authenticated via Face ID</p>
                  <p className="text-xs text-gray-500">{formatDate(loginTime)} at {formatTime(loginTime)}</p>
                </div>
              </div>
            </div>
          )}

          {confidence > 0 && (
            <div className="mt-4 flex flex-wrap justify-center gap-2">
              <span className="inline-flex items-center gap-1.5 rounded-full bg-[#3b82f6]/10 px-4 py-1.5 text-sm font-medium text-[#60a5fa]">
                <span className="h-1.5 w-1.5 rounded-full bg-[#3b82f6]" />
                {confidence}% match confidence
              </span>
              {embedded && (
                <span className="inline-flex items-center gap-1.5 rounded-full bg-green-500/10 px-4 py-1.5 text-sm font-medium text-green-400">
                  <span className="h-1.5 w-1.5 rounded-full bg-green-500 animate-pulse" />
                  Host notified
                </span>
              )}
            </div>
          )}

          <div className="mt-8 flex flex-col gap-3">
            <button onClick={onLock} className="flex w-full items-center justify-center gap-2 rounded-xl bg-[#1a1a2e] px-6 py-3.5 font-semibold text-white transition hover:bg-[#252540]">
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <rect x="3" y="11" width="18" height="11" rx="2" ry="2" /><path d="M7 11V7a5 5 0 0 1 10 0v4" />
              </svg>
              Lock Screen
            </button>
            <button onClick={onReset} className="rounded-xl px-6 py-3 text-sm text-gray-500 transition hover:text-red-400">
              Reset Face ID
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
