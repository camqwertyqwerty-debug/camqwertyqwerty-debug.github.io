"use client";

import React, { useCallback, useEffect, useRef, useState } from "react";
import CameraPrompt from "./CameraPrompt";
import { LoadingScreen, NotRecognizedScreen, LoggedInScreen } from "./FaceIdScreens";
import {
  type AppState,
  type StoredFace,
  MODEL_URL,
  euclideanDistance,
  getStoredFace,
  saveStoredFace,
  clearStoredFace,
} from "@/lib/face-id-utils";
import {
  notifyVerificationSuccess,
  notifyVerificationFailure,
  notifyStatus,
  listenForHostCommands,
  isEmbedded,
} from "@/lib/face-id-messaging";

declare const faceapi: any;

export default function FaceIdApp() {
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const animFrameRef = useRef<number>(0);
  const scanStartRef = useRef<number>(0);

  const [state, setState] = useState<AppState>("loading");
  const [modelsLoaded, setModelsLoaded] = useState(false);
  const [feedback, setFeedback] = useState("Initializing...");
  const [userName, setUserName] = useState("");
  const [nameInput, setNameInput] = useState("");
  const [showNamePrompt, setShowNamePrompt] = useState(false);
  const [capturedDescriptor, setCapturedDescriptor] = useState<number[] | null>(null);
  const [confidence, setConfidence] = useState(0);
  const [loginTime, setLoginTime] = useState<Date | null>(null);
  const [matchAnim, setMatchAnim] = useState(false);
  const [scanPulse, setScanPulse] = useState(false);
  const [modelLoadProgress, setModelLoadProgress] = useState(0);
  const [cameraError, setCameraError] = useState<string | null>(null);
  const [nextState, setNextState] = useState<"register" | "login-scan">("register");
  const [embedded] = useState(() => (typeof window !== "undefined" ? isEmbedded() : false));

  /* ---------- listen for commands from host window ---------- */
  useEffect(() => {
    if (!embedded) return;
    const cleanup = listenForHostCommands((command) => {
      switch (command) {
        case "lock":
          handleLock();
          break;
        case "reset":
          handleReset();
          break;
        case "request-status":
          notifyStatus(
            state === "register" ? "registering" :
            state === "login-scan" ? "scanning" :
            state === "logged-in" ? "matched" :
            state === "not-recognized" ? "not-recognized" :
            state === "loading" ? "loading" :
            state === "camera-prompt" ? "camera-prompt" : "loading",
            state === "logged-in" ? `Authenticated as ${userName}` : undefined
          );
          break;
      }
    });
    return cleanup;
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [embedded, state, userName]);

  /* ---------- notify host of state changes ---------- */
  useEffect(() => {
    if (!embedded) return;
    switch (state) {
      case "loading":
        notifyStatus("loading", "Loading face recognition models...");
        break;
      case "camera-prompt":
        notifyStatus("camera-prompt", "Waiting for camera permission");
        break;
      case "register":
        notifyStatus("registering", "User is registering their face");
        break;
      case "login-scan":
        notifyStatus("scanning", "Scanning face for verification");
        break;
      case "not-recognized":
        notifyStatus("not-recognized", "Face was not recognized");
        notifyVerificationFailure();
        break;
      case "logged-in":
        notifyStatus("matched", `Authenticated as ${userName}`);
        break;
    }
  }, [embedded, state, userName]);

  /* ---------- load face-api from CDN ---------- */
  const waitForFaceApi = useCallback((): Promise<void> => {
    return new Promise((resolve) => {
      const check = () => {
        if (typeof faceapi !== "undefined") resolve();
        else setTimeout(check, 100);
      };
      check();
    });
  }, []);

  /* ---------- load models ---------- */
  useEffect(() => {
    let cancelled = false;
    async function loadModels() {
      try {
        await waitForFaceApi();
        if (cancelled) return;
        setModelLoadProgress(15);
        await faceapi.nets.ssdMobilenetv1.loadFromUri(MODEL_URL);
        if (cancelled) return;
        setModelLoadProgress(45);
        await faceapi.nets.faceLandmark68Net.loadFromUri(MODEL_URL);
        if (cancelled) return;
        setModelLoadProgress(75);
        await faceapi.nets.faceRecognitionNet.loadFromUri(MODEL_URL);
        if (cancelled) return;
        setModelLoadProgress(100);
        setModelsLoaded(true);
      } catch (err) {
        console.error("Failed to load face-api models", err);
        setFeedback("Failed to load face recognition models. Please refresh.");
      }
    }
    loadModels();
    return () => { cancelled = true; };
  }, [waitForFaceApi]);

  /* ---------- decide initial state once models ready ---------- */
  useEffect(() => {
    if (!modelsLoaded) return;
    const stored = getStoredFace();
    if (stored) {
      setUserName(stored.name);
      setNextState("login-scan");
    } else {
      setNextState("register");
    }
    setState("camera-prompt");
  }, [modelsLoaded]);

  /* ---------- webcam start / stop ---------- */
  const startCamera = useCallback(async () => {
    try {
      setCameraError(null);

      // First check if getUserMedia is available
      if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
        setCameraError(
          "Camera API is not available. This may be because the app is running in an embedded frame. Try opening the app in a new tab."
        );
        return false;
      }

      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: "user", width: 480, height: 480 },
      });
      streamRef.current = stream;
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
      }
      return true;
    } catch (err: any) {
      console.error("Camera error:", err?.name, err?.message, err);
      let message: string;
      if (err?.name === "NotAllowedError" || err?.name === "PermissionDeniedError") {
        // Check if we're inside an iframe — the iframe might not have camera permissions
        const isIframe = window.self !== window.top;
        if (isIframe) {
          message =
            "Camera access is blocked because the app is running inside an embedded frame. Please open the app directly in a new browser tab to use Face ID.";
        } else {
          message =
            "Camera access was denied. Please allow camera access in your browser settings and try again.";
        }
      } else if (err?.name === "NotFoundError" || err?.name === "DevicesNotFoundError") {
        message = "No camera found. Please connect a camera and try again.";
      } else if (err?.name === "NotReadableError" || err?.name === "TrackStartError") {
        message = "Camera is already in use by another application. Please close it and try again.";
      } else if (err?.name === "OverconstrainedError") {
        // Try again with no constraints
        try {
          const stream = await navigator.mediaDevices.getUserMedia({ video: true });
          streamRef.current = stream;
          if (videoRef.current) {
            videoRef.current.srcObject = stream;
          }
          return true;
        } catch {
          message = "Could not access camera with the requested settings.";
        }
      } else {
        message = `Could not access camera: ${err?.message || "Unknown error"}. Try opening the app in a new browser tab.`;
      }
      setCameraError(message!);
      setFeedback(message!);
      return false;
    }
  }, []);

  const stopCamera = useCallback(() => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach((t) => t.stop());
      streamRef.current = null;
    }
    if (animFrameRef.current) {
      cancelAnimationFrame(animFrameRef.current);
      animFrameRef.current = 0;
    }
  }, []);

  const handleGrantCamera = useCallback(async () => {
    setCameraError(null);
    const success = await startCamera();
    if (success) {
      setState(nextState);
    }
  }, [startCamera, nextState]);

  /* ---------- manage camera on state changes ---------- */
  useEffect(() => {
    if (state === "register" || state === "login-scan") {
      if (!streamRef.current) {
        startCamera().then((success) => {
          if (success && videoRef.current && streamRef.current) {
            videoRef.current.srcObject = streamRef.current;
          }
        });
      } else if (videoRef.current && !videoRef.current.srcObject) {
        videoRef.current.srcObject = streamRef.current;
      }
      if (state === "login-scan") {
        scanStartRef.current = Date.now();
        setScanPulse(true);
      }
    } else if (state !== "camera-prompt") {
      stopCamera();
      setScanPulse(false);
    }
    return () => {
      if (state !== "register" && state !== "login-scan" && state !== "camera-prompt") {
        stopCamera();
      }
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [state]);

  /* ---------- registration detection loop ---------- */
  useEffect(() => {
    if (state !== "register" || !modelsLoaded) return;
    let running = true;

    async function detectLoop() {
      const video = videoRef.current;
      if (!video || !running || video.readyState < 2) {
        if (running) animFrameRef.current = requestAnimationFrame(detectLoop);
        return;
      }
      try {
        const detection = await faceapi.detectSingleFace(video).withFaceLandmarks().withFaceDescriptor();
        if (!running) return;
        if (!detection) {
          setFeedback("No face detected — look at the camera");
        } else {
          const box = detection.detection.box;
          const vw = video.videoWidth;
          const vh = video.videoHeight;
          const positions = detection.landmarks.positions;
          if (positions.length < 68) {
            setFeedback("Move closer — full face needed");
          } else {
            const faceCenterX = box.x + box.width / 2;
            const faceCenterY = box.y + box.height / 2;
            const offX = Math.abs(faceCenterX - vw / 2) / vw;
            const offY = Math.abs(faceCenterY - vh / 2) / vh;
            const faceArea = (box.width * box.height) / (vw * vh);
            if (faceArea < 0.04) {
              setFeedback("Move closer to the camera");
            } else if (offX > 0.15 || offY > 0.15) {
              setFeedback("Center your face in the frame");
            } else {
              setFeedback("Hold still... ✓ Face detected!");
              setTimeout(() => {
                if (!running) return;
                const descriptor = Array.from(detection.descriptor as Float32Array);
                setCapturedDescriptor(descriptor);
                setShowNamePrompt(true);
                setFeedback("Great! Now enter your name.");
              }, 800);
              return;
            }
          }
        }
      } catch { /* ignore */ }
      if (running) animFrameRef.current = requestAnimationFrame(detectLoop);
    }

    function waitForVideo() {
      const video = videoRef.current;
      if (video && video.readyState >= 2) {
        setFeedback("Position your face in the frame");
        detectLoop();
      } else if (running) {
        setTimeout(waitForVideo, 200);
      }
    }
    const timeout = setTimeout(waitForVideo, 300);
    return () => { running = false; clearTimeout(timeout); if (animFrameRef.current) cancelAnimationFrame(animFrameRef.current); };
  }, [state, modelsLoaded]);

  /* ---------- login scan loop ---------- */
  useEffect(() => {
    if (state !== "login-scan" || !modelsLoaded) return;
    const storedFace = getStoredFace();
    if (!storedFace) return;
    let running = true;

    async function scanLoop() {
      const video = videoRef.current;
      if (!video || !running || video.readyState < 2) {
        if (running) animFrameRef.current = requestAnimationFrame(scanLoop);
        return;
      }
      try {
        const detection = await faceapi.detectSingleFace(video).withFaceLandmarks().withFaceDescriptor();
        if (!running) return;
        if (detection) {
          const desc = Array.from(detection.descriptor as Float32Array);
          const dist = euclideanDistance(desc, storedFace.descriptor);
          if (dist < 0.6) {
            const conf = Math.max(0, Math.min(100, Math.round((1 - dist / 0.6) * 100)));
            setConfidence(conf);
            setUserName(storedFace.name);
            setMatchAnim(true);
            setScanPulse(false);
            notifyVerificationSuccess(storedFace.name, conf);
            setTimeout(() => { if (!running) return; setLoginTime(new Date()); setState("logged-in"); }, 1500);
            return;
          } else {
            setFeedback("Scanning... keep looking at the camera");
          }
        } else {
          setFeedback("Looking for your face...");
        }
      } catch { /* ignore */ }
      if (Date.now() - scanStartRef.current > 5000) {
        if (running) setState("not-recognized");
        return;
      }
      if (running) animFrameRef.current = requestAnimationFrame(scanLoop);
    }

    function waitForVideo() {
      const video = videoRef.current;
      if (video && video.readyState >= 2) {
        setFeedback("Scanning your face...");
        scanLoop();
      } else if (running) {
        setTimeout(waitForVideo, 200);
      }
    }
    const timeout = setTimeout(waitForVideo, 300);
    return () => { running = false; clearTimeout(timeout); if (animFrameRef.current) cancelAnimationFrame(animFrameRef.current); };
  }, [state, modelsLoaded]);

  /* ---------- actions ---------- */
  function handleRegister() {
    if (!nameInput.trim() || !capturedDescriptor) return;
    const data: StoredFace = { name: nameInput.trim(), descriptor: capturedDescriptor };
    saveStoredFace(data);
    setUserName(data.name);
    setFeedback(`Face ID registered! You're all set, ${data.name}.`);
    setShowNamePrompt(false);
    notifyVerificationSuccess(data.name, 100);
    setTimeout(() => { setLoginTime(new Date()); setState("logged-in"); }, 2000);
  }

  function handleReset() {
    clearStoredFace();
    setUserName(""); setNameInput(""); setCapturedDescriptor(null);
    setShowNamePrompt(false); setMatchAnim(false); setConfidence(0);
    setFeedback("Position your face in the frame");
    setState("camera-prompt");
    setNextState("register");
  }

  function handleRetry() {
    setMatchAnim(false);
    setFeedback("Scanning your face...");
    setState("login-scan");
  }

  function handleLock() {
    setMatchAnim(false); setConfidence(0);
    setState("login-scan");
  }

  /* ================================================================ */
  /*  RENDER                                                          */
  /* ================================================================ */

  if (state === "loading") return <LoadingScreen progress={modelLoadProgress} />;

  if (state === "camera-prompt") {
    return <CameraPrompt mode={nextState} userName={userName} cameraError={cameraError} onGrantCamera={handleGrantCamera} />;
  }

  if (state === "register") {
    return (
      <div className="flex min-h-screen items-center justify-center bg-[#0a0a0f] p-4">
        <div className="w-full max-w-[500px]">
          <div className="mb-6 text-center">
            <div className="mx-auto mb-3 flex h-12 w-12 items-center justify-center rounded-full bg-[#3b82f6]/10">
              <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#3b82f6" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <path d="M9 3H5a2 2 0 0 0-2 2v4" /><path d="M15 3h4a2 2 0 0 1 2 2v4" /><path d="M9 21H5a2 2 0 0 1-2-2v-4" /><path d="M15 21h4a2 2 0 0 0 2-2v-4" />
                <circle cx="12" cy="10" r="3" /><path d="M12 13c-3 0-5.5 1.5-6 4h12c-.5-2.5-3-4-6-4z" />
              </svg>
            </div>
            <h1 className="text-2xl font-bold text-white">Welcome! Let&apos;s set up Face ID</h1>
            <p className="mt-1 text-sm text-gray-400">Position your face in the frame below</p>
          </div>
          <div className="relative mx-auto aspect-square w-full max-w-[400px] overflow-hidden rounded-3xl border-2 border-[#1a1a2e] shadow-[0_0_40px_rgba(59,130,246,0.08)]">
            <video ref={videoRef} autoPlay playsInline muted className="h-full w-full object-cover" style={{ transform: "scaleX(-1)" }} />
            <canvas ref={canvasRef} className="absolute inset-0 h-full w-full" />
            {!showNamePrompt && (
              <div className="pointer-events-none absolute inset-0 flex items-center justify-center">
                <div className="h-[55%] w-[42%] rounded-[50%] border-2 border-dashed border-[#3b82f6]/50 shadow-[0_0_20px_rgba(59,130,246,0.15)]" />
              </div>
            )}
            {showNamePrompt && (
              <div className="absolute inset-0 flex items-center justify-center bg-black/50 backdrop-blur-sm">
                <div className="flex h-20 w-20 items-center justify-center rounded-full bg-green-500/20">
                  <svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="#22c55e" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round"><polyline points="20 6 9 17 4 12" /></svg>
                </div>
              </div>
            )}
          </div>
          <div className="mt-4 text-center">
            <p className={`text-sm font-medium ${feedback.includes("✓") || feedback.includes("registered") ? "text-green-400" : feedback.includes("denied") || feedback.includes("Failed") ? "text-red-400" : "text-[#60a5fa]"}`}>{feedback}</p>
          </div>
          {showNamePrompt && (
            <div className="mt-6 animate-in fade-in slide-in-from-bottom-4 duration-300">
              <div className="rounded-2xl border border-[#1a1a2e] bg-[#0f0f1a] p-6">
                <label className="mb-2 block text-sm font-medium text-gray-300">What should we call you?</label>
                <input type="text" value={nameInput} onChange={(e) => setNameInput(e.target.value)} onKeyDown={(e) => e.key === "Enter" && handleRegister()} placeholder="Enter your name" autoFocus className="w-full rounded-xl border border-[#1a1a2e] bg-[#0a0a0f] px-4 py-3 text-white placeholder-gray-600 outline-none transition focus:border-[#3b82f6] focus:ring-1 focus:ring-[#3b82f6]" />
                <button onClick={handleRegister} disabled={!nameInput.trim()} className="mt-4 w-full rounded-xl bg-[#3b82f6] px-6 py-3 font-semibold text-white transition hover:bg-[#2563eb] disabled:opacity-40 disabled:cursor-not-allowed">Register Face ID</button>
              </div>
            </div>
          )}
        </div>
      </div>
    );
  }

  if (state === "login-scan") {
    return (
      <div className="flex min-h-screen items-center justify-center bg-[#0a0a0f] p-4">
        <div className="w-full max-w-[500px]">
          <div className="mb-6 text-center">
            <h1 className="text-2xl font-bold text-white">Face ID Login</h1>
            <p className="mt-1 text-sm text-gray-400">Look at the camera to sign in</p>
          </div>
          <div className="relative mx-auto aspect-square w-full max-w-[400px] overflow-hidden rounded-3xl border-2 border-[#1a1a2e] shadow-[0_0_40px_rgba(59,130,246,0.08)]">
            <video ref={videoRef} autoPlay playsInline muted className="h-full w-full object-cover" style={{ transform: "scaleX(-1)" }} />
            {scanPulse && !matchAnim && (
              <div className="pointer-events-none absolute inset-0">
                <div className="scan-line absolute left-0 right-0 h-[2px] bg-gradient-to-r from-transparent via-[#3b82f6] to-transparent" />
              </div>
            )}
            {scanPulse && !matchAnim && (
              <div className="pointer-events-none absolute inset-0 flex items-center justify-center">
                <div className="h-[55%] w-[42%] animate-pulse rounded-[50%] border-2 border-[#3b82f6]/60 shadow-[0_0_30px_rgba(59,130,246,0.2)]" />
              </div>
            )}
            {matchAnim && (
              <div className="absolute inset-0 flex flex-col items-center justify-center bg-black/60 backdrop-blur-sm animate-in fade-in duration-300">
                <div className="flex h-24 w-24 items-center justify-center rounded-full bg-green-500/20 animate-in zoom-in duration-500">
                  <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="#22c55e" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round"><polyline points="20 6 9 17 4 12" /></svg>
                </div>
                <p className="mt-4 text-xl font-bold text-white">Welcome back, {userName}!</p>
                <p className="mt-1 text-sm text-green-400">Confidence: {confidence}%</p>
              </div>
            )}
          </div>
          <div className="mt-4 text-center">
            <p className="text-sm font-medium text-[#60a5fa]">{feedback}</p>
          </div>
          <div className="mt-8 flex justify-center">
            <button onClick={handleReset} className="rounded-lg px-4 py-2 text-xs text-gray-500 transition hover:text-gray-300">Reset Face ID</button>
          </div>
        </div>
      </div>
    );
  }

  if (state === "not-recognized") return <NotRecognizedScreen onRetry={handleRetry} onReset={handleReset} />;
  if (state === "logged-in") return <LoggedInScreen userName={userName} loginTime={loginTime} confidence={confidence} onLock={handleLock} onReset={handleReset} embedded={embedded} />;

  return null;
}