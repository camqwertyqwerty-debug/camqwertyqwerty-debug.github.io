"use client";

import dynamic from "next/dynamic";

const FaceIdApp = dynamic(() => import("@/components/FaceIdApp"), { ssr: false });

export default function HomePage() {
  return <FaceIdApp />;
}
